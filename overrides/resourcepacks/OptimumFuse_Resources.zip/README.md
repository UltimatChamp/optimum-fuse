# OptimumFuse Resources
_Important resources for OptimumFuse!_

* * *

### Credits

1) **ToolTips Stylized** _(https://modrinth.com/resourcepack/tooltips-stylized)_<br>
For the Creative tabs format used in `lang/en_us.json`!