# OptimumFuse Resources
_Important resources for OptimumFuse!_

* * *

### Credits

- **ToolTips Stylized** _(https://modrinth.com/resourcepack/tooltips-stylized)_
